/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
  typedef enum {
    BL_ERR_OK        = 0,    // Updated firmware successfully
    BL_ERR_SLOT      = 1,    // no SD card in slot
    BL_ERR_MOUNT     = 2,    // could not mount SD card
    BL_ERR_NOBINARY  = 3,    // could not find binary
    BL_ERR_UNLOCK    = 4,    // could not unlock flash
    BL_ERR_READ      = 5,    // error when reading flash
    BL_ERR_WRITE     = 6,    // error when writing flash
    BL_ERR_ERASE     = 7,    // error when erasing flash
    BL_ERR_UNKNOWN   = 99,   // other failure
  } BOOTLOADER_ERROR;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern const volatile uint32_t * pFLASH;

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
#define FLASH_APP_OFFSET 0x10000UL
#define SD_SPI_HANDLE hspi1
#define SD_CS_GPIO_Port SPI1_NSS1_GPIO_Port
#define SD_CS_Pin SPI1_NSS1_Pin

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LCD_RESET_Pin GPIO_PIN_11
#define LCD_RESET_GPIO_Port GPIOC
#define LCD_BL_Pin GPIO_PIN_12
#define LCD_BL_GPIO_Port GPIOC
#define HTR_EN_Pin GPIO_PIN_13
#define HTR_EN_GPIO_Port GPIOC
#define SPI1_NSS1_Pin GPIO_PIN_0
#define SPI1_NSS1_GPIO_Port GPIOF
#define SPI2_NSS1_Pin GPIO_PIN_1
#define SPI2_NSS1_GPIO_Port GPIOF
#define SWD_NRST_Pin GPIO_PIN_2
#define SWD_NRST_GPIO_Port GPIOF
#define SPI2_NSS3_Pin GPIO_PIN_0
#define SPI2_NSS3_GPIO_Port GPIOC
#define SPI2_NSS4_Pin GPIO_PIN_1
#define SPI2_NSS4_GPIO_Port GPIOC
#define SPI2_NSS5_Pin GPIO_PIN_2
#define SPI2_NSS5_GPIO_Port GPIOC
#define SWD_DETECT_Pin GPIO_PIN_3
#define SWD_DETECT_GPIO_Port GPIOC
#define SWD_DETECT_EXTI_IRQn EXTI2_3_IRQn
#define EXP_AN1_Pin GPIO_PIN_2
#define EXP_AN1_GPIO_Port GPIOA
#define EXP_AN2_Pin GPIO_PIN_3
#define EXP_AN2_GPIO_Port GPIOA
#define SPI2_NSS2_Pin GPIO_PIN_5
#define SPI2_NSS2_GPIO_Port GPIOA
#define CONTRAST_POT_Pin GPIO_PIN_6
#define CONTRAST_POT_GPIO_Port GPIOA
#define PWR_INT_Pin GPIO_PIN_7
#define PWR_INT_GPIO_Port GPIOA
#define USER_1_Pin GPIO_PIN_0
#define USER_1_GPIO_Port GPIOB
#define USER_1_EXTI_IRQn EXTI0_1_IRQn
#define USER_2_Pin GPIO_PIN_1
#define USER_2_GPIO_Port GPIOB
#define USER_2_EXTI_IRQn EXTI0_1_IRQn
#define USER_3_Pin GPIO_PIN_2
#define USER_3_GPIO_Port GPIOB
#define USER_3_EXTI_IRQn EXTI2_3_IRQn
#define MSD_DETECT_Pin GPIO_PIN_12
#define MSD_DETECT_GPIO_Port GPIOB
#define MSD_DETECT_EXTI_IRQn EXTI4_15_IRQn
#define EXP_INT2_Pin GPIO_PIN_13
#define EXP_INT2_GPIO_Port GPIOB
#define EXP_INT2_EXTI_IRQn EXTI4_15_IRQn
#define EXP_INT1_Pin GPIO_PIN_14
#define EXP_INT1_GPIO_Port GPIOB
#define EXP_INT1_EXTI_IRQn EXTI4_15_IRQn
#define VLV_HOME_Pin GPIO_PIN_15
#define VLV_HOME_GPIO_Port GPIOB
#define VLV_HOME_EXTI_IRQn EXTI4_15_IRQn
#define VLV_MTR_2_Pin GPIO_PIN_8
#define VLV_MTR_2_GPIO_Port GPIOA
#define VLV_MTR_1_Pin GPIO_PIN_9
#define VLV_MTR_1_GPIO_Port GPIOA
#define STPR_HOME_Pin GPIO_PIN_6
#define STPR_HOME_GPIO_Port GPIOC
#define STPR_STEP_Pin GPIO_PIN_7
#define STPR_STEP_GPIO_Port GPIOC
#define STPR_DIR_Pin GPIO_PIN_9
#define STPR_DIR_GPIO_Port GPIOD
#define STPR_EN_Pin GPIO_PIN_10
#define STPR_EN_GPIO_Port GPIOA
#define SWD_SWDIO_Pin GPIO_PIN_13
#define SWD_SWDIO_GPIO_Port GPIOA
#define SWD_SWCLK_Pin GPIO_PIN_14
#define SWD_SWCLK_GPIO_Port GPIOA
#define LED1_Pin GPIO_PIN_15
#define LED1_GPIO_Port GPIOA
#define LED2_Pin GPIO_PIN_8
#define LED2_GPIO_Port GPIOC
#define LED3_Pin GPIO_PIN_9
#define LED3_GPIO_Port GPIOC
#define EXP_PWM1_Pin GPIO_PIN_0
#define EXP_PWM1_GPIO_Port GPIOD
#define EXP_PWM2_Pin GPIO_PIN_1
#define EXP_PWM2_GPIO_Port GPIOD
#define EXP_RESET_Pin GPIO_PIN_2
#define EXP_RESET_GPIO_Port GPIOD
#define STPR_DCEN_Pin GPIO_PIN_4
#define STPR_DCEN_GPIO_Port GPIOD
#define LED4_Pin GPIO_PIN_3
#define LED4_GPIO_Port GPIOB
#define STPR_DCO_Pin GPIO_PIN_4
#define STPR_DCO_GPIO_Port GPIOB
#define STPR_DCO_EXTI_IRQn EXTI4_15_IRQn
#define LEAK_DETECT_Pin GPIO_PIN_5
#define LEAK_DETECT_GPIO_Port GPIOB
#define LEAK_DETECT_EXTI_IRQn EXTI4_15_IRQn
#define STPR_DIAG0_Pin GPIO_PIN_6
#define STPR_DIAG0_GPIO_Port GPIOB
#define STPR_DIAG0_EXTI_IRQn EXTI4_15_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
