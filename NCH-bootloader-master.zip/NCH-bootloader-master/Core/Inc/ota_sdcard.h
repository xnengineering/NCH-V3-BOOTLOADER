/**
 * @file  : ota_sdcard.h
 * @brief : firmware update from binary located on SD card
 */

#ifndef OTA_UPDATE_H
#define OTA_UPDATE_H

#include "main.h"

#define FW_PATH "app.bin"
BOOTLOADER_ERROR updateSD(void);

#endif /* OTA_UPDATE_H_ */
