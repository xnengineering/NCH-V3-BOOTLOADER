/**
 * @file  : ota_sdcard.c
 * @brief : firmware update from binary located on SD card
 */

#include <stdio.h>
#include <string.h>
#include "main.h"
#include "ota_sdcard.h"
#include "app_fatfs.h"

/**
 * @brief erase a page of Flash
 * @param none
 * @retval BOOTLOADER_ERROR
 */
static HAL_StatusTypeDef eraseFlashPage(uint32_t addr) {
  uint32_t page = (addr - FLASH_BASE) / FLASH_PAGE_SIZE;
  FLASH_EraseInitTypeDef eraseConfig = {
      .TypeErase = FLASH_TYPEERASE_PAGES,
      .Banks = page > FLASH_PAGE_NB ? FLASH_BANK_2 : FLASH_BANK_1,
      .Page = page,
      .NbPages = 1
  };
  HAL_StatusTypeDef halErr = HAL_FLASHEx_Erase(&eraseConfig, &addr);
  if (HAL_OK != halErr)
    printf("Flash Erase Error Bank %lu: HAL(%d), PAGE(0x%08lX)\r\n", eraseConfig.Banks, halErr, addr);
  return halErr;
}

/**
 * @brief update firmware from SD card if available
 * @param none
 * @retval BOOTLOADER_ERROR
 */
BOOTLOADER_ERROR updateSD(void) {
  HAL_StatusTypeDef halErr = HAL_OK;
  BOOTLOADER_ERROR blErr = BL_ERR_OK;

  // check detect pin
  if (HAL_GPIO_ReadPin(MSD_DETECT_GPIO_Port, MSD_DETECT_Pin) == GPIO_PIN_SET)
    return BL_ERR_SLOT;

  FATFS fatFS;
  FRESULT fres;

  // try to mount the SD Card now
  if (FR_OK != (fres = f_mount(&fatFS, "", 1))) {
    printf("No SD Card found : (%i)\r\n", fres);
    return BL_ERR_MOUNT;
  }

  printf("SD Card Mounted Successfully!!!\r\n");

  FIL file;
  if(FR_OK != (fres = f_open(&file, FW_PATH, FA_WRITE | FA_READ | FA_OPEN_EXISTING))) {
    printf("No Firmware found in SD Card : (%i)\r\n", fres);
    blErr = BL_ERR_NOBINARY;
    goto updateSD_CLEANUP;
  }

  UINT fw_size = f_size(&file);
  printf("Firmware found in SD Card. \r\nFW Size = %d Bytes\r\n", fw_size);

  printf("Unlocking the App Flash memory...\r\n");
  if(HAL_OK != (halErr = HAL_FLASH_Unlock())) {
    printf("Unable to unlock FLASH: Status(%d)\r\n", halErr);
    blErr = BL_ERR_UNLOCK;
    goto updateSD_CLEANUP;
  }
  FLASH_WaitForLastOperation(HAL_MAX_DELAY);
  __HAL_FLASH_CLEAR_FLAG(
      FLASH_FLAG_EOP      | /*!< 0x00000001 FLASH End of operation flag */
      FLASH_FLAG_OPERR    | /*!< 0x00000002 FLASH Operation error flag */
      FLASH_FLAG_PROGERR  | /*!< 0x00000008 FLASH Programming error flag */
      FLASH_FLAG_WRPERR   | /*!< 0x00000010 FLASH Write protection error flag */
      FLASH_FLAG_PGAERR   | /*!< 0x00000020 FLASH Programming alignment error flag */
      FLASH_FLAG_SIZERR   | /*!< 0x00000040 FLASH Size error flag  */
      FLASH_FLAG_PGSERR   | /*!< 0x00000080 FLASH Programming sequence error flag */
      FLASH_FLAG_MISERR   | /*!< 0x00000100 FLASH Fast programming data miss error flag */
      FLASH_FLAG_FASTERR    /*!< 0x00000200 FLASH Fast programming error flag */
  );

  /* must erase entire bank, or one page at a time followed by write */
  //printf("Erasing the App Flash memory...\r\n");
  //eraseFlash(fw_size);

  UINT bytesRead, bytesWritten = 0;
  BYTE bytes[FLASH_PAGE_SIZE];

  // calculate pages
  const uint32_t totalPgs = (fw_size + FLASH_PAGE_SIZE - 1) / FLASH_PAGE_SIZE; // ceiling
  const uint32_t firstPg = (FLASH_APP_OFFSET/FLASH_PAGE_SIZE);
  uint32_t cntPg = 0;

  printf("Writing the binary to Flash memory...\r\n");
  while (bytesWritten < fw_size) {
    memset(bytes, 0, FLASH_PAGE_SIZE); // clear the buffer
    if(FR_OK != (fres = f_read(&file, bytes, FLASH_PAGE_SIZE, &bytesRead))) { // load page
      printf("FW Read Error: (%i)\r\n", fres);
      blErr = BL_ERR_READ;
      goto updateSD_CLEANUP;
    }
    printf("Read %d more bytes...\r\n", bytesRead);

    // select page
    uint32_t pg = firstPg + cntPg;
    uint32_t pgAddr = FLASH_BASE + (FLASH_PAGE_SIZE * pg);

    // erase page
    printf("Erasing Flash memory page %lu (%lu of %lu pages)\r\n", pg, cntPg+1, totalPgs);
    if(HAL_OK != (halErr = eraseFlashPage(pgAddr))) {
      printf("Error erasing flash: HAL(%d)\r\n", halErr);
      blErr = BL_ERR_ERASE;
      goto updateSD_CLEANUP;
    };

    // write page, 1 row at a time
    for(uint32_t i = 0; i < bytesRead; i += 0x100) {
      if(HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_FAST, pgAddr + i, (uint32_t)bytes + i)) {
        printf("App Flash Write Error, byte %ld: Err(0x%04lx)\r\n", i, pFlash.ErrorCode);
        blErr = BL_ERR_WRITE;
        goto updateSD_CLEANUP;
      };
    }
    bytesWritten += bytesRead;
    cntPg++;
    printf("Wrote %d of %d bytes...\r\n", bytesWritten, fw_size);
  }

  updateSD_CLEANUP:
    printf("Locking the App Flash memory...\r\n");
    HAL_FLASH_Lock();
    FLASH_WaitForLastOperation(HAL_MAX_DELAY);

    f_close(&file);
    if (blErr == BL_ERR_OK) {
      if (FR_OK != (fres = f_unlink(FW_PATH "~")))
        printf("Could not remove FW file backup: FERR(%d)\r\n", fres);
      if (FR_OK != (fres = f_rename(FW_PATH, FW_PATH "~")))
        printf("Could not rename FW file: FERR(%d)\r\n", fres);
    }
    f_mount(NULL, "", 0);

  printf("Done updating Firmware\r\n");
  return BL_ERR_OK;
}
